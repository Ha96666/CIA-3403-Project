
const express = require('express');
const cors = require('cors');
const mongoClient = require('mongodb').MongoClient;
const bodyParser = require('body-parser'); //read from data and from fields
const methodOverride = require('method-override'); //to support PUT and DELETE FROM browssers

const app = express();
app.use(cors());
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({extended:false}));
app.use(methodOverride('_method'));

//const mongoServerURL = "mongodb://localhost:27017";
const mongoServerURL = "mongodb://HamadAlblooshi:Hamadalblooshi50@ds127634.mlab.com:27634/watchdb";

//default route / - display all movie
app.get('/', (request, response, next) => {
	mongoClient.connect(mongoServerURL, (err, db) => {
		if (err)
			console.log("Cannot connect to Mongo:"+err.message);

		//connect to database
		const watchdb = db.db("watchdb");

		//read from db watchtv collection
		watchdb.collection("watchtv").find({}).toArray((err, watchArray) => {
			if (err)
				console.log(err.message);
console.log(watchArray);

			response.send(JSON.stringify(watchArray));
		});

		//close the connection to the db
		db.close();
	});

});

//get one movie by title - used in update and delete web pages
app.get('/watchtv/:title', (request, response, next) => {

	const titleValue = request.params.titleValue;

	mongoClient.connect(mongoServerURL, (err, db) => {
		if (err)
			console.log("Cannot connect to Mongo:"+err.message);

		//connect to watchdb
		const watchdb = db.db("watchdb");

		console.log(titleValue);
		//build the query filter
		let query = {titleValue:titleValue};

		//read from watchdb watchtv collection
		watchdb.collection("watchtv").find(query).toArray((err, watchArray) => {
			if (err)
				console.log(err.message);

			response.send(JSON.stringify(watchArray));
		});

		//close the connection to the db
		db.close();
	});

});

//example of hardcoded route
app.get('/Series', (request, response, next) => {
	mongoClient.connect(mongoServerURL, (err, db) => {
		if (err)
			console.log("Cannot connect to Mongo:"+err.message);

		//connect to item
		const watchdb = db.db("watchdb");

		//read from itemdb items collection
		watchdb.collection("watchtv").find({type:"Series"}).toArray((err, watchArray) => {
			if (err)
				console.log(err.message);

			response.send(JSON.stringify(watchArray));
		});

		//close the connection to the db
		db.close();
	});
});

//example to used to handle many routes using request parameter
//here the request parameter is :Type
app.get('/:Type', (request, response, next) => {
	mongoClient.connect(mongoServerURL, (err, db) => {
		if (err)
			console.log("Cannot connect to Mongo:"+err.message);

		//connect to item
		const watchdb = db.db("watchdb");
		let TypeValue = request.params.Type;
		if (TypeValue == "series")
			TypeValue = "Series";
		else if (TypeValue == "movies")
			TypeValue = "Movies";
		console.log(TypeValue);
		//build the query filter
		let query = {Type:TypeValue};

		//read from itemdb items collection
		watchdb.collection("watchtv").find(query).toArray((err, watchtvArray) => {
			if (err)
				console.log(err.message);

			response.send(JSON.stringify(watchtvArray));
		});

		//close the connection to the db
		db.close();
	});
});

//add a new item - using HTTP POST method
app.post('/watchtv', (request, response, next) => {
	//access the form fields by the same names as in the HTML form
	const titleValue = request.body.title;
	console.log(titleValue);
	const typeValue = request.body.type;
	let productionYearValue = request.body.production_year;
	let rateValue = request.body.rate;
	//convert price to number
	rateValue = parseFloat(rateValue);
	productionYearValue = parseFloat(productionYearValue);

	mongoClient.connect(mongoServerURL, (err, db) => {
		if (err)
			console.log("Cannot connect to Mongo:"+err.message);

		//connect to itemdb
		const watchdb = db.db("watchdb");
		
		const newTitle = {title:titleValue, type:typeValue, production_year:productionYearValue
						,rate:rateValue};
		//insert to itemdb items collection
		watchdb.collection("watchtv").insertOne(newTitle, (err, result) => {
			if (err) {
				console.log(err.message);
			}

			if (result.insertedCount == 1) {
				//one way - return response - let client handle it
				//response.end("Item " + itemName + " added successfully!");
				
				//another way - redirect to the all items page - showing item added
				response.redirect("/static/index.html");
			}
			else
				response.end("Title " + titleValue + " could not be added!!");

			//response.send(JSON.stringify(newItem));
		});

		//close the connection to the db
		db.close();
	});	
});

//update item - uisng HTTP PUT method
app.put('/watchtv', (request, response, next) => {
	console.log("in PUT");
	const titleValue = request.param('title');
	const typeValue = request.param('type');
	let productionYearValue = request.param('production_year');
	let rateValue = request.param('rate');
	//convert price to number
	rateValue = parseFloat(rateValue)
	productionYearValue = parseFloat(productionYearValue);

	mongoClient.connect(mongoServerURL, (err, db) => {
		if (err)
			console.log("Cannot connect to Mongo:"+err.message);

		//connect to item
		const watchdb = db.db("watchdb");
		
		//we are updating by the item_name
		const updateFilter = {title:titleValue};
		const updateValues = {$set:{type:typeValue, production_year:productionYearValue,
						rate:rateValue}};
		//insert from itemdb items collection
		watchdb.collection("watchtv").updateOne(updateFilter, updateValues, (err, res) => {
			if (err) {
				console.log(err.message);
			}

			//console.log("matchcount " + res.matchedCount);
			//console.log("updatecount:" + res.modifiedCount);

			//one way 
			//const responseJSON = {updateCount:res.result.nModified};
			//response.send(JSON.stringify(responseJSON));

			//another way - redirect to all items page
			response.redirect("/static/index.html");
		});

		//close the connection to the db
		db.close();
	});	
});

//delete item by item name
app.delete('/watchtv', (request, response, next) => {
	const titleValue = request.param('title');

	mongoClient.connect(mongoServerURL, (err, db) => {
		if (err)
			console.log("Cannot connect to Mongo:"+err.message);

		//connect to item
		const watchdb = db.db("watchdb");
		
		//we are deleting by the item_name
		const deleteFilter = {title:titleValue};

		//insert from itemdb items collection
		watchdb.collection("watchtv").deleteOne(deleteFilter, (err, res) => {
			if (err) {
				console.log(err.message);
			}

			//const responseJSON = {deleteCount:res.result.n}; //n - how many docs deleted
			//response.send(JSON.stringify(responseJSON));

			if (res.deletedCount > 0) {
				response.redirect("/static/index.html");
			}
			else {
				response.send("<script>alert(\"deleted \" +title);</script>");
			}
		});

		//close the connection to the db
		db.close();
	});	
});


//set the route for static HTML files to /static
//actual folder containing HTML files will be public
app.use('/static', express.static('public'));

//start the web server
const port = process.env.PORT;
app.listen(7878, ()=> {
	console.log("server listening on "+7878);
});

